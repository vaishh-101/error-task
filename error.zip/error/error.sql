-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 23, 2021 at 03:25 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `error`
--

-- --------------------------------------------------------

--
-- Table structure for table `signup info`
--

CREATE TABLE `signup info` (
  `id` int(255) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup info`
--

INSERT INTO `signup info` (`id`, `fullname`, `email`, `password`, `created_at`) VALUES
(1, '[vaishnavi]', '[test@mail.com]', '[vlc1223]', '0000-00-00 00:00:00'),
(2, 'uykhfhgf', 'test@fksjr', 'tyfky', '2021-12-16 10:28:32'),
(3, 'uykhfhgf', 'test@fksjr', 'tyfky', '2021-12-16 10:53:50'),
(4, 'sjlsjkhngrjkl', 'trwtjkhnwwlkrtjh@fksjr', 'tyfkrfjh0439853y', '2021-12-16 10:55:11'),
(5, 'sjlsjkhngrjkl', 'trwtjkhnwwlkrtjh@fksjr', 'tyfkrfjh0439853y', '2021-12-16 13:05:29'),
(6, 'sjlsjkhngrjkl', 'trwtjkhnwwlkrtjh@fksjr', 'tyfkrfjh0439853y', '2021-12-16 13:05:44'),
(7, 'sjlsjkhngrjkl', 'trwtjkhnwwlkrtjh@fksjr', 'tyfkrfjh0439853y', '2021-12-16 13:17:22'),
(8, 'Vaishnavi Lalit choudhary ', 'vaishnavichoudhary200@gmail.com', 'vaishanmbsdmb', '2021-12-17 16:07:02'),
(9, 'Vaishnavi Lalit Choudhary ', 'vaishnavichoudhary200@gmail.com', 'Vaishnavi@00', '2021-12-22 07:17:31'),
(10, 'Vaishnavi Lalit', 'ytdkty3@fg', 'fjdtuji', '2021-12-22 07:18:43'),
(11, '', '', '', '2021-12-22 07:23:03'),
(12, '', '', '', '2021-12-22 07:45:35'),
(13, '', '', '', '2021-12-22 07:45:57'),
(14, 'Vaishnavi Lalit', 'vaishnavichoudhary200@gmail.com', 'jttyfki', '2021-12-22 07:46:09'),
(15, 'Vaishnavi Lalit', 'vaishnavichoudhary200@gmail.com', 'jttyfki', '2021-12-22 07:48:15'),
(16, 'Vaishnavi Lalit', 'vaishnavichoudhary200@gmail.com', 'hfj', '2021-12-22 07:48:24'),
(17, 'Vaishnavi lalit Choudhary', 'vaishnavichoudhary200@gmail.com', '12345678', '2021-12-23 13:31:06'),
(18, 'v', '', '', '2021-12-23 13:58:40'),
(19, 'Vaishnavi Lalit', '', '', '2021-12-23 13:58:48'),
(20, 'Vaishnavi Lalit choudhary', '', '', '2021-12-23 14:01:19'),
(21, 'Vaishnavi Lalit choudhary', '12', 'djyhkuyjkl', '2021-12-23 14:02:08'),
(22, 't', '', '', '2021-12-23 14:03:57'),
(23, '', '', '', '2021-12-23 14:18:07'),
(24, '', '', '', '2021-12-23 14:22:40'),
(25, 'Vaishnavi Lalit', '', '', '2021-12-23 14:22:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `signup info`
--
ALTER TABLE `signup info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `signup info`
--
ALTER TABLE `signup info`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
