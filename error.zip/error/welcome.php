
<?php
	include 'partials/connection.php';
  

     if(isset($_POST["Import"])){
        
        $filename=$_FILES["file"]["tmp_name"];    
         if($_FILES["file"]["size"] > 0)
         {
            $file = fopen($filename, "r");
			
              while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
               {
                $sql1 = "INSERT INTO `signup info` ( `fullname`, `email`, `password`)
 values ('".$getData[0]."','".$getData[1]."','".$getData[2]."')";
                       $result = mysqli_query($con, $sql);
            if(!isset($result))
            {
              echo "<script type=\"text/javascript\">
                  alert(\"Invalid File:Please Upload CSV File.\");
                  window.location = \"index.php\"
                  </script>";    
            }
            else {
                echo "<script type=\"text/javascript\">
                alert(\"CSV File has been successfully Imported.\");
                window.location = \"index.php\"
              </script>";
            }
               }
          
               fclose($file);  
         }
      }   
	      ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>index</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="welcome.php">Great Journey</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      
    </ul>
  </div>
</nav>

<div class="container">
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">

      <div class="item active">
        <img src="images/1.jpg" alt="Having an journey is always so much fun!"
         style="width:100%;">
        <div class="carousel-caption">
         
          <p>Having an journey is always so much fun!</p>
        </div>
      </div>

      <div class="item">
        <img src="images/2.jpg" alt="Having a Journey is a good Change!" 
        style="width:100%;">
        <div class="carousel-caption">
          
          <p>Having a Journey is a good Change!</p>
        </div>
      </div>
    
      <div class="item">
        <img src="images/3.jpg" alt="We love the Beautiful World!" 
        style="width:100%;">
        <div class="carousel-caption">
          
          <p>We love the Beautiful World!</p>
        </div>
      </div>
  
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
<br>
<br>
<br>
<div id="wrap">
            <div class="container">
                <div class="row">
<form class="form-horizontal" action="functions.php" 
method="post" name="upload_excel" enctype="multipart/form-data">
             <fieldset>
                            <!-- File Button -->
                            <div class="form-group">
  <label class="col-md-4 control-label" for="filebutton">Select File</label>
                                <div class="col-md-4">
     <input type="file" name="file" id="file" class="input-large" required>
                        </div>
                         </div>
                      <!-- Button -->
          <div class="form-group">
 <label class="col-md-4 control-label" for="singlebutton">Import data</label>
         <div class="col-md-4">
<button type="submit" id="submit" name="Import" 
class="btn btn-primary button-loading" data-loading-text="Loading...">Upload</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
              </div>
</div>
</div>
</body>
</html>