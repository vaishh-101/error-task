<?php 

include 'partials/connection.php';

//$login = false;

if($_SERVER["REQUEST_METHOD"] == "POST"){
  
  $email = $_POST["email"];
  $pwd = $_POST["pwd"];

  $sql = "Select * from users where email='$email' AND password='$pwd'";
  $result = mysqli_query($conn,$sql);
  $num = mysqli_num_rows($result);
  if ($num == 1) {
    $login = true;
  } else {
    echo "failed too connect";
  }
  

  }


?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>login.php</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>

 <?php require 'partials/_nav.php' ?>

 <div class="card" style="width: 70rem;">

 <div class="container my-4">
    <h1 class="text">login to our website</h1>
</div>

<form class="form-horizontal" action="login.php" method="post">
  <div class="form-group">
  <label class="control-label col-sm-2" for="email">Email:</label>
    <div class="col-sm-3">
      <input type="email" class="form-control" id="email" placeholder="Enter email">
    </div>
 </div>

  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Password:</label>
    <div class="col-sm-3">
      <input type="password" class="form-control" id="pwd" placeholder="Enter password">
    </div>
  </div>
  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" name="login_user" class="btn btn-primary mb-3">Login</button>
      <p>Not a user ?<a href="signup.php"><b>Sign up</b><a></p>
    </div>
  </div>

</form>
</div>
    </body>
</html>