<?php
if(isset($_POST["sub"]))
{
    header('Location:Welcome.php');
}
?>

<?php
include 'partials/connection.php';
if(isset($_POST["sub"])){
    $fname = $_POST["fname"];
    $email = $_POST["email"];
    $pwd = $_POST["pwd"];
    $sql1 = "INSERT INTO `signup info` ( `fullname`, `email`, `password`, `created_at`) VALUES ('$fname', '$email', '$pwd', CURRENT_TIMESTAMP)";
    $res1 = mysqli_query($conn,$sql1);
    if($res1){
       // echo 'successfully inserted';
    }else{
        //echo 'sorry unsuccessfull';
    }
}
$fullname_error = $email_error =  $password_error = "";
$fullname = $email = $password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

if (empty($_POST['fullname'])) {
    $fullname_error = "Full name Should be at least 2 characters";
}

if (empty($_POST['email'])) {
    $email_error = "Email must be a valid Email.";
}

if (empty($_POST['password'])) {
     $password_error = "password must contain at least 6 Characters";
}

}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>signup</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="">
</head>
<body>

    <?php require 'partials/_nav.php' ?>


    <?php
    $sql = "select * from `signup info`";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        //echo "successfully";
        while ($row = mysqli_fetch_assoc($result)) {
            $id = $row['id'];
            $fullname = $row['fullname'];
            $email = $row['email'];
            $password = $row['password'];
            //echo $email;
        }
    }else{
        //echo 'unsu';
    }
    ?>
    

    <div class="card" style="width: 70rem;">
    <p><span class="error">* required field</span></p>


        <div class="container my-4">
            <h1 class="text">Signup to our website</h1>
        </div>

        <form class="form-horizontal" action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"] );?> method="post">
            <div class="form-group">
                <label class="control-label col-sm-2" for="fullname">FullName:

                </label>
                <div class="col-sm-5">
                    <input type="fullname" class="form-control" id="fullname" 
                    placeholder="Enter Full name" name="fname"><span class
                    ="error">* <?php echo $fullname_error;?></span>
                </div>
            </div>
            <div class="form-group">

                <label class="control-label col-sm-2" for="email">Email:</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="email" 
                    placeholder="Enter email" name="email">
                    <span class="error">* <?php echo $email_error;?></span>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-2" for="password">
                    Password:</label>
                <div class="col-sm-5">
                    <input type="password" class="form-control" id="password" 
                    placeholder="Enter password" name="pwd">
                    <span class="error">* <?php echo $password_error;?></span>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-primary mb-3" 
                    name="sub" value="redirect">Submit</button>


                    <p>
                        Already a user ?<a href="login.php"><b>Log in</b><a>
                        </p>
                        </div>
                    </div>

                </form>
            </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js
/bootstrap.bundle.min.js"></script>
        </body>
    </html>